#pragma once

struct Point
{
    double x;
    double y;
};