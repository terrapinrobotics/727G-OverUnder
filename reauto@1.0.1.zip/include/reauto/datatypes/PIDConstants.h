#pragma once

struct PIDConstants
{
    double kP;
    double kI = 0;
    double kD = 0;
};