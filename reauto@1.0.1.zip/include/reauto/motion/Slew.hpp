#pragma once

#include <cmath>

namespace reauto {
namespace util {
void slew(double current, double& target, double step);
}
}